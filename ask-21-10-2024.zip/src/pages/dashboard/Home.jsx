import React from "react";
import Layout from "../../layout/Layout";

const Home = () => {
 

  return (
    <Layout>
      <div className="flex  items-center justify-center p-16 font-bold text-4xl text-gray-500 animate-pulse">Coming Soon....</div>
    </Layout>
  );
};

export default Home;
