import React from 'react'
import Layout from '../../layout/Layout'

const Developer = () => {
  return (
   <Layout>
     <div>Developer</div>
   </Layout>
  )
}

export default Developer